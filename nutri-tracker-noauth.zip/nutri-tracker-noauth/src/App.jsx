import { useEffect, useMemo, useState } from "react";
import BarcodeScanner from "./components/BarcodeScanner";
import ProductForm from "./components/ProductForm";
import DaySummary from "./components/DaySummary";
import EntryList from "./components/EntryList";
import { todayISO } from "./lib/dates";
import { getSessionId } from "./lib/session";
import { getOrCreateProduct, saveProduct } from "./lib/products";
import { addDiaryEntry, listDiaryEntriesByDate } from "./lib/diary";
import { scaleNutrients, addNutrients } from "./lib/nutrition";

export default function App() {
  const sessionId = useMemo(() => getSessionId(), []);
  const [date, setDate] = useState(todayISO());
  const [meal, setMeal] = useState("breakfast");
  const [grams, setGrams] = useState(100);

  const [scannerOpen, setScannerOpen] = useState(false);
  const [activeProduct, setActiveProduct] = useState(null);

  const [entries, setEntries] = useState([]);
  const [productsByBarcode, setProductsByBarcode] = useState({});
  const [status, setStatus] = useState("");

  const loadDay = async (d) => {
    setStatus("Lade Tag…");
    try {
      const list = await listDiaryEntriesByDate(sessionId, d);
      setEntries(list);

      // Load products used that day (simple MVP)
      const needed = Array.from(new Set(list.map(x => x.productBarcode)));
      const cache = { ...productsByBarcode };

      for (const bc of needed) {
        if (!cache[bc]) {
          const p = await getOrCreateProduct(bc);
          cache[bc] = p;
        }
      }

      setProductsByBarcode(cache);
      setStatus("");
    } catch (e) {
      setStatus(e?.message || "Fehler beim Laden");
    }
  };

  useEffect(() => { loadDay(date); /* eslint-disable-next-line */ }, [date]);

  const totals = useMemo(() => {
    let sum = {};
    for (const e of entries) {
      const p = productsByBarcode[e.productBarcode];
      if (!p) continue;
      sum = addNutrients(sum, scaleNutrients(p.nutrientsPer100g, e.grams));
    }
    return sum;
  }, [entries, productsByBarcode]);

  const onDetected = async (barcode) => {
    setScannerOpen(false);
    setStatus("Lade Produkt…");
    const p = await getOrCreateProduct(barcode);
    setActiveProduct(p);
    setProductsByBarcode((prev) => ({ ...prev, [barcode]: p }));
    setStatus("");
  };

  const saveActiveProduct = async (patch) => {
    if (!activeProduct) return;
    setStatus("Speichere Produkt…");
    await saveProduct(activeProduct.barcode, patch);
    const updated = { ...activeProduct, ...patch };
    setActiveProduct(updated);
    setProductsByBarcode((prev) => ({ ...prev, [updated.barcode]: updated }));
    setStatus("Produkt gespeichert ✅");
    setTimeout(() => setStatus(""), 800);
  };

  const addEntry = async () => {
    if (!activeProduct) return;
    setStatus("Speichere Eintrag…");
    await addDiaryEntry(sessionId, {
      date,
      meal,
      grams: Number(grams) || 0,
      productBarcode: activeProduct.barcode,
    });
    setActiveProduct(null);
    await loadDay(date);
    setStatus("Gespeichert ✅");
    setTimeout(() => setStatus(""), 800);
  };

  return (
    <div style={{ padding: 24, maxWidth: 980, margin: "0 auto" }} className="grid">
      <div className="row" style={{ justifyContent: "space-between" }}>
        <div className="grid" style={{ gap: 6 }}>
          <h1>Nutri Tracker</h1>
          <small>
            Kein Login: Daten werden pro Gerät/Browser über eine lokale Session-ID gespeichert.
            (Session: <code>{sessionId.slice(0, 8)}…</code>)
          </small>
        </div>
      </div>

      <div className="row card" style={{ justifyContent: "space-between" }}>
        <div className="row">
          <button onClick={() => setScannerOpen(true)}>Barcode scannen</button>

          <label>
            Datum
            <input style={{ marginLeft: 8 }} type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </label>

          <label>
            Mahlzeit
            <select style={{ marginLeft: 8 }} value={meal} onChange={(e) => setMeal(e.target.value)}>
              <option value="breakfast">Frühstück</option>
              <option value="lunch">Mittag</option>
              <option value="dinner">Abend</option>
              <option value="snack">Snack</option>
            </select>
          </label>

          <label>
            Gramm
            <input style={{ marginLeft: 8, width: 110 }} type="number" min="0" value={grams} onChange={(e) => setGrams(e.target.value)} />
          </label>
        </div>

        <small>{status}</small>
      </div>

      {scannerOpen && (
        <BarcodeScanner onDetected={onDetected} onClose={() => setScannerOpen(false)} />
      )}

      <DaySummary totals={totals} />

      {activeProduct && (
        <div className="card grid">
          <div className="row" style={{ justifyContent: "space-between" }}>
            <div>
              <div style={{ fontWeight: 900 }}>{activeProduct.name}</div>
              <small>{activeProduct.barcode}</small>
            </div>

            <div className="row">
              <button onClick={addEntry}>Eintragen</button>
              <button onClick={() => setActiveProduct(null)}>Schließen</button>
            </div>
          </div>

          <ProductForm product={activeProduct} onSave={saveActiveProduct} />

          <small>
            Hinweis: Ohne Login sind deine Firestore-Rules in diesem Projekt absichtlich offen.
            Das ist okay für ein privates MVP, aber nicht für “Internet offen”.
          </small>
        </div>
      )}

      <div className="grid">
        <h2 style={{ marginTop: 8 }}>Einträge ({date})</h2>
        <EntryList entries={entries} productsByBarcode={productsByBarcode} />
      </div>
    </div>
  );
}
