import { useEffect, useRef, useState } from "react";
import { BrowserMultiFormatReader } from "@zxing/browser";

export default function BarcodeScanner({ onDetected, onClose }) {
  const videoRef = useRef(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let stopFn = null;
    let zxingReader = null;
    let rafId = null;

    const cleanup = () => {
      try { if (rafId) cancelAnimationFrame(rafId); } catch {}
      try { stopFn?.(); } catch {}
      try { zxingReader?.reset?.(); } catch {}
    };

    const start = async () => {
      setError("");

      // Prefer native BarcodeDetector if available
      if ("BarcodeDetector" in window) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: "environment" },
            audio: false,
          });

          const video = videoRef.current;
          video.srcObject = stream;
          await video.play();

          const detector = new window.BarcodeDetector({
            formats: ["ean_13", "ean_8", "upc_a", "upc_e", "code_128"],
          });

          const tick = async () => {
            try {
              const barcodes = await detector.detect(video);
              if (barcodes?.length) {
                const value = barcodes[0].rawValue;
                cleanup();
                onDetected(value);
                return;
              }
            } catch {}
            rafId = requestAnimationFrame(tick);
          };

          rafId = requestAnimationFrame(tick);
          stopFn = () => stream.getTracks().forEach((t) => t.stop());
          return;
        } catch {
          // fallback below
        }
      }

      // ZXing fallback
      try {
        zxingReader = new BrowserMultiFormatReader();
        const controls = await zxingReader.decodeFromVideoDevice(
          null,
          videoRef.current,
          (result) => {
            if (result) {
              const value = result.getText();
              cleanup();
              onDetected(value);
            }
          }
        );
        stopFn = () => controls.stop();
      } catch {
        setError("Scanner konnte nicht gestartet werden. Kamera-Berechtigungen prüfen.");
      }
    };

    start();
    return cleanup;
  }, [onDetected]);

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", padding: 16, zIndex: 1000 }}>
      <div style={{ maxWidth: 520, margin: "0 auto", background: "#111", borderRadius: 12, padding: 12 }}>
        <div style={{ display: "flex", justifyContent: "space-between", color: "#fff", alignItems: "center" }}>
          <div>Barcode scannen</div>
          <button onClick={onClose} style={{ padding: "6px 10px" }}>Schließen</button>
        </div>

        <video
          ref={videoRef}
          style={{ width: "100%", marginTop: 12, borderRadius: 12, background: "#000" }}
          muted
          playsInline
        />

        {error && <div style={{ color: "#ff6b6b", marginTop: 10 }}>{error}</div>}
        <div style={{ color: "#aaa", marginTop: 10, fontSize: 12 }}>
          Tipp: gutes Licht + Barcode ruhig halten.
        </div>
      </div>
    </div>
  );
}
