export default function DaySummary({ totals }) {
  const kcal = totals?.kcal || 0;
  const p = totals?.protein_g || 0;
  const c = totals?.carbs_g || 0;
  const f = totals?.fat_g || 0;

  return (
    <div className="card">
      <div style={{ fontWeight: 800, marginBottom: 6 }}>Tages-Summe</div>
      <div>Kalorien: {kcal.toFixed(0)} kcal</div>
      <div>P/C/F: {p.toFixed(1)} g / {c.toFixed(1)} g / {f.toFixed(1)} g</div>
      <small>Mikros funktionieren genauso: einfach Felder wie iron_mg, magnesium_mg in nutrientsPer100g ergänzen.</small>
    </div>
  );
}
