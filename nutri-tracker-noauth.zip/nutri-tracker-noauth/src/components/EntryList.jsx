export default function EntryList({ entries, productsByBarcode }) {
  if (!entries.length) return <div className="card"><small>Keine Einträge für diesen Tag.</small></div>;

  return (
    <div className="grid">
      {entries.map((e) => {
        const p = productsByBarcode[e.productBarcode];
        return (
          <div key={e.id} className="card">
            <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
              <div>
                <div style={{ fontWeight: 800 }}>
                  {p?.name || "Unbekannt"}{" "}
                  <span style={{ color: "#666", fontWeight: 400 }}>({e.productBarcode})</span>
                </div>
                <small>{e.meal} · {e.grams} g</small>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
