import { useEffect, useState } from "react";

export default function ProductForm({ product, onSave }) {
  const [name, setName] = useState("");
  const [brand, setBrand] = useState("");
  const [kcal, setKcal] = useState(0);
  const [protein, setProtein] = useState(0);
  const [carbs, setCarbs] = useState(0);
  const [fat, setFat] = useState(0);

  useEffect(() => {
    if (!product) return;
    setName(product.name || "");
    setBrand(product.brand || "");
    setKcal(product.nutrientsPer100g?.kcal ?? 0);
    setProtein(product.nutrientsPer100g?.protein_g ?? 0);
    setCarbs(product.nutrientsPer100g?.carbs_g ?? 0);
    setFat(product.nutrientsPer100g?.fat_g ?? 0);
  }, [product]);

  const submit = (e) => {
    e.preventDefault();
    onSave({
      name: name.trim() || "Unbekanntes Produkt",
      brand: brand.trim(),
      nutrientsPer100g: {
        kcal: Number(kcal) || 0,
        protein_g: Number(protein) || 0,
        carbs_g: Number(carbs) || 0,
        fat_g: Number(fat) || 0
      }
    });
  };

  return (
    <form onSubmit={submit} className="grid">
      <div className="row">
        <label style={{ flex: 1 }}>
          Name
          <input style={{ marginLeft: 8, flex: 1 }} value={name} onChange={(e) => setName(e.target.value)} />
        </label>
        <label style={{ flex: 1 }}>
          Marke
          <input style={{ marginLeft: 8, flex: 1 }} value={brand} onChange={(e) => setBrand(e.target.value)} />
        </label>
      </div>

      <div className="row">
        <label>
          kcal/100g
          <input style={{ marginLeft: 8, width: 120 }} type="number" value={kcal} onChange={(e) => setKcal(e.target.value)} />
        </label>
        <label>
          Protein g/100g
          <input style={{ marginLeft: 8, width: 120 }} type="number" value={protein} onChange={(e) => setProtein(e.target.value)} />
        </label>
        <label>
          Carbs g/100g
          <input style={{ marginLeft: 8, width: 120 }} type="number" value={carbs} onChange={(e) => setCarbs(e.target.value)} />
        </label>
        <label>
          Fett g/100g
          <input style={{ marginLeft: 8, width: 120 }} type="number" value={fat} onChange={(e) => setFat(e.target.value)} />
        </label>
      </div>

      <button type="submit">Produkt speichern</button>
    </form>
  );
}
